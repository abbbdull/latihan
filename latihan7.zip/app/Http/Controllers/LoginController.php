<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use GuzzleHttp\Client;

class LoginController extends Controller
{
    private $apiUrl = 'localhost/latihan6/api/register/proses';
    public function index()
    {
        return view('auth.login');
    }

    public function register(Request $request)
    {

        $response = Http::put("{$this->apiUrl}", $request->all());
        $produk = $response->json();
        dd($request);
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required|string|min:8',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $client = new Client();
        $data = [
            'email' => $request->email,
            'password' => $request->password,
        ];

        try {
            $response = $client->post('http://localhost/latihan6/api/login_proses', [
                'json' => $data,
            ]);

            $responseBody = json_decode($response->getBody(), true);
            // dd($responseBody);
            if (isset($responseBody['token'])) {
                $user = $responseBody['user'];
                $id = $user['id'];
                $name = $user['name'];
                $email = $user['email'];
                $id_role = $user['id_role'];

                // dd($user);
                session(['api_token' => $responseBody['token']]);
                session(['id' => $id]);
                session(['name' => $name]);
                session(['email' => $email]);
                session(['id_role' => $id_role]);


                return redirect()->route('cart')->with('success', 'Berhasil Masuk!');
            };
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $responseBody = json_decode($response->getBody(), true);

            // return response()->json($responseBody, $response->getStatusCode());
        }
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
        ]);
    }
}
